# Instalador de cursores Android Morado (ASCII para evitar problemas de codificacion)
$destino = "C:\Users\oscar\Pictures\CursorMorado"

$origen = $PSScriptRoot
if ([string]::IsNullOrEmpty($origen)) { $origen = (Get-Location).Path }

if (-not (Test-Path -LiteralPath (Join-Path $origen "pointer.cur"))) {
    Write-Host "ERROR: No encuentro pointer.cur en $origen. Ejecuta el script desde la carpeta descomprimida." -ForegroundColor Red
    return
}

New-Item -ItemType Directory -Force -Path $destino | Out-Null
if ((Resolve-Path -LiteralPath $origen).Path -ne (Resolve-Path -LiteralPath $destino).Path) {
    Get-ChildItem -LiteralPath $origen -Include *.cur,*.ani -Recurse -File |
        Copy-Item -Destination $destino -Force
}

$cursores = [ordered]@{
    "Arrow"       = "pointer.cur"
    "Help"        = "help.cur"
    "AppStarting" = "work.ani"
    "Wait"        = "busy.ani"
    "Crosshair"   = "cross.cur"
    "IBeam"       = "text.cur"
    "NWPen"       = "hand.cur"
    "No"          = "unavailiable.cur"
    "SizeNS"      = "vert.cur"
    "SizeWE"      = "horz.cur"
    "SizeNWSE"    = "dgn1.cur"
    "SizeNESW"    = "dgn2.cur"
    "SizeAll"     = "move.cur"
    "UpArrow"     = "alternate.cur"
    "Hand"        = "link.cur"
    "Pin"         = "pin.cur"
    "Person"      = "person.cur"
}

$ruta = "HKCU:\Control Panel\Cursors"
$fallos = 0
foreach ($clave in $cursores.Keys) {
    $archivo = Join-Path $destino $cursores[$clave]
    if (Test-Path -LiteralPath $archivo) {
        Set-ItemProperty -Path $ruta -Name $clave -Value $archivo
    } else {
        Write-Host "No se encontro: $archivo" -ForegroundColor Yellow
        $fallos++
    }
}

Set-ItemProperty -Path $ruta -Name "(Default)" -Value "Android Morado"
Set-ItemProperty -Path $ruta -Name "Scheme Source" -Value 1

if (-not ("Cur" -as [type])) {
Add-Type @"
using System.Runtime.InteropServices;
public class Cur {
    [DllImport("user32.dll", SetLastError=true)]
    public static extern bool SystemParametersInfo(int a, int b, int c, int d);
}
"@
}
[Cur]::SystemParametersInfo(0x0057, 0, 0, 0x03) | Out-Null

if ($fallos -eq 0) {
    Write-Host "Listo: cursores Android Morado instalados en $destino" -ForegroundColor Green
} else {
    Write-Host "Terminado con $fallos archivo(s) que faltan." -ForegroundColor Yellow
}
